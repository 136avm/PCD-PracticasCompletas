/**
 * Contiene las clases necesarias para simular el funcionamiento de una tienda con múltiples clientes y cajas.
 * Se usa paso de mensajes para su implementación.
 * @author Álvaro Aledo Tornero
 * @author Antonio Vergara Moya
 */
package ejercicio4;