/**
 * Este paquete contiene las clases y los hilos utilizados en el ejercicio 1.
 * Proporciona implementaciones para simular operaciones en arrays de enteros, 
 * realizando operaciones de generación, consumo y suma de datos usando cerrojos.
 * @author Álvaro Aledo Tornero
 * @author Antonio Vergara Moya
 */
package ejercicio1;